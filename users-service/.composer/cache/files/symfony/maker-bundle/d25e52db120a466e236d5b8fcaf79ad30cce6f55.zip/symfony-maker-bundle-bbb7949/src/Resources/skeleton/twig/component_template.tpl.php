<div{{ attributes }}>
    <!-- component html -->
</div>
