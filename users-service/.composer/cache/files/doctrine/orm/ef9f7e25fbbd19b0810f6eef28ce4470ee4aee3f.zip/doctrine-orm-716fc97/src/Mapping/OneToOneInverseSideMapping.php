<?php

declare(strict_types=1);

namespace Doctrine\ORM\Mapping;

final class OneToOneInverseSideMapping extends ToOneInverseSideMapping implements OneToOneAssociationMapping
{
}
